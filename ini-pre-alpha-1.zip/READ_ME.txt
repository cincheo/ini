
To run INI (UNIX/MAC users):

1. Go to the INI root directory
2. Type the command "./bin/ini"

The first time, you may need to give the execution rights first: "chmod +x ./bin/ini"
You may also want to add the ini command to the PATH.

WINDOWS users: write your own run script

Some examples are available at {rootdir}/ini/examples.

Documentation at: http://perso.isep.fr/rpawlak/ini/
